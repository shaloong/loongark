declare module "@ark-ui/svelte" {
  export const ark: Record<string, unknown> & {
    button: any;
    div: any;
    input: any;
    span: any;
    textarea: any;
    footer: any;
  };
  export function createListCollection<T = any>(options: { items: T[] }): any;
}
