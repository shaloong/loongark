# Page snapshot

```yaml
- main [ref=e2]:
  - heading "Conversation reading fixture" [level=1] [ref=e3]
  - generic [ref=e6]:
    - article [ref=e7]:
      - paragraph [ref=e8]: "Message 0: keep this paragraph in view while other messages change."
      - text: New text
    - article [ref=e9]:
      - paragraph [ref=e10]: "Message 1: keep this paragraph in view while other messages change."
    - article [ref=e11]:
      - paragraph [ref=e12]: "Message 2: keep this paragraph in view while other messages change."
    - article [ref=e13]:
      - paragraph [ref=e14]: "Message 3: keep this paragraph in view while other messages change."
    - article [ref=e15]:
      - paragraph [ref=e16]: "Message 4: keep this paragraph in view while other messages change."
    - article [ref=e17]:
      - paragraph [ref=e18]: "Message 5: keep this paragraph in view while other messages change."
    - article [ref=e19]:
      - paragraph [ref=e20]: "Message 6: keep this paragraph in view while other messages change."
    - article [ref=e21]:
      - paragraph [ref=e22]: "Message 7: keep this paragraph in view while other messages change."
    - article [ref=e23]:
      - paragraph [ref=e24]: "Message 8: keep this paragraph in view while other messages change."
    - article [ref=e25]:
      - paragraph [ref=e26]: "Message 9: keep this paragraph in view while other messages change."
    - article [ref=e27]:
      - paragraph [ref=e28]: "Message 10: keep this paragraph in view while other messages change."
    - article [ref=e29]:
      - paragraph [ref=e30]: "Message 11: keep this paragraph in view while other messages change."
```